import React from "react";

import NewExpreses from "./NewExpenses.css";
import expenses from "./expensesForm";

const NewExpenses = () => {
    return (
        <div className="New-Expenses">
            <newExpenses />
        </div>
    )
}

export default NewExpenses;