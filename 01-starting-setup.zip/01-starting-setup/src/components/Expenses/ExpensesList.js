import React from "react";

import "./ExpensesList.css"
const ExpensesList = props => {
    {filteredExpenses.map((expense) => {
        <ExpenseItem
            key={expense.id}
            title={props.items [2].title}
            amount={props.items [2].amount)
                date={props.items [2].date}
                ></ExpenseItem>
                ))}
}

export default ExpenseList;